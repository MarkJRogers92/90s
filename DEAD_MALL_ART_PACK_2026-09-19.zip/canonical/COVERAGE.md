# DEAD MALL canonical art coverage

This ledger controls what counts as canonical production/reference work. Generated images are not canonical merely because they exist in chat or on the art branch.

## Locked existing coverage

- Master palette / material ramps — covered; do not regenerate as a standalone overview.
- Player scale / base appearance — covered; do not regenerate as a standalone overview.
- Four-direction movement concept — covered; only add genuinely missing animation frames.
- Eight-direction aiming / held-equipment concept — covered; do not regenerate another overview.
- Portrait style / expressions — covered conceptually; only add new character-specific portrait work.
- World pickup + detailed item portrait relationship — covered; extend with new items rather than redraw the same examples.
- Generic mall tile/material language — covered conceptually; future work must add production-ready modular pieces, not another overview collage.
- Core mall props — substantially covered; future work must add missing props only.
- Storefront/signage language — covered conceptually; store-specific kits may extend it.
- Basic enemy/boss scale — covered conceptually; future enemy sheets must add animation/content.

## Canonical sequence status

| Sheet | Subject | Status | Review result |
|---|---|---|---|
| 01 | Master player scale + proportions | covered by approved source set | locked; no redraw |
| 02 | Player movement frame guide | coverage exists in approved movement sources | do not replace with collage |
| 03 | 8-direction aimed arms / weapon overlay | coverage exists in approved aim/held-equipment sources | locked; no redraw |
| 04 | Master mall tileset | concept coverage exists | dedicated Aseprite-ready joins/corners/export pieces still pending |
| 05 | Mall props | substantial coverage exists | extend missing props only |
| 06 | Generic 1990s electronics store kit | FINALIZED REFERENCE SET | seven accepted variants are one collective kit; do not regenerate another electronics overview |
| 07 | Electronics merchandise closeups | FINALIZED CURATED REFERENCE | merchandise-only 28-item sheet; brand-neutral, no DVD/storefront/player/fusion filler |
| 08 | Video rental store kit | FINALIZED CANONICAL REFERENCE | dedicated rental-store kit; VHS shelving, genre signage, return slot, counter/back-room, props and shelf states; no real brands or DVD filler |
| 09 | Music store kit | NEXT | must add genuinely new music-retail fixtures and merchandise |
| 10 | Arcade kit | pending | must be genuinely new |

## Quality gate before finalizing any future sheet

A sheet may be finalized only if all are true:

1. It matches the canonical sheet number and subject from the original visual-production brief.
2. It adds material not already covered by a locked sheet or source board.
3. It does not reuse filler panels of player/palette/item material merely to fill space.
4. It is production-oriented enough to hand to an Aseprite artist.
5. Store/environment sheets preserve the established 3/4 top-down, 640x360 medium-close game view and shared material language.
6. Fictional retail identity is legally distinct: no copied logos or real brand names.
7. Period details are appropriate to 1990s mall retail; unusual late-decade objects must be deliberate rather than accidental.
8. Any failed or duplicate generation is explicitly rejected and not added to the canonical folder.
9. Before finalization, perform a content audit against all earlier canonical sheets and the original brief; if a panel is duplicate filler, anachronistic, or contains a real brand, reject or rebuild it.

Rejected generations remain non-canonical even if they exist elsewhere in the chat or preview folders. Sheet 06 is a collective accepted reference set; Sheets 07 and 08 were produced under the stricter audit gate.
